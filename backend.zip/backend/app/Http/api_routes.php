<?php
	
$api = app('Dingo\Api\Routing\Router');

$api->version('v1', function ($api) {

	$api->post('auth/login', 'App\Api\V1\Controllers\AuthController@login');
	$api->post('auth/signup', 'App\Api\V1\Controllers\AuthController@signup');
	$api->post('auth/recovery', 'App\Api\V1\Controllers\AuthController@recovery');
	$api->post('auth/reset', 'App\Api\V1\Controllers\AuthController@reset');

	$api->get('schema', ['middleware' => ['api.auth'], 'uses' => 'App\Api\V1\Controllers\SchemaController@getAllSchema']);
	$api->get('schema/{id}', ['middleware' => ['api.auth'], 'uses' => 'App\Api\V1\Controllers\SchemaController@getSchema']);
	$api->post('schema', ['middleware' => ['api.auth'], 'uses' => 'App\Api\V1\Controllers\SchemaController@addSchema']);
});
