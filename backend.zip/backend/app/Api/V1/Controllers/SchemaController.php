<?php

namespace App\Api\V1\Controllers;

use App\User;
use App\Diagram;
use Illuminate\Http\Request;
use Dingo\Api\Routing\Helpers;
use App\Http\Controllers\Controller;


class SchemaController extends Controller
{
    use Helpers;

    public function getAllSchema(Request $request)
    {
        /* @var User $user */
        $user = $this->auth->user();
        $diagrams = $user->diagrams()->get();
        $metas = [];
        foreach ($diagrams as $diagram) {
            $metas[] = $diagram->getMeta();
        }

        return $metas;
    }

    public function getSchema(Request $request, $id)
    {
        /* @var User $user */
        $user = $this->auth->user();
        $diagram = $user->diagrams()->where('id', $id)->get()->first();

        return $diagram;
    }

    public function addSchema(Request $request)
    {
        /* @var User $user */
        $user = $this->auth->user();

//        if ($request->has('id')) {
//            $schemaId = $request->get('id');
//            /* @var Diagram $schema */
//            $user->diagrams()->where('id', $schemaId)->update($request->only(['data']));
//            return ['success' => 'true', 'id' => $schemaId];
//        }

        $newSchema = $user->diagrams()->create($request->only(['name', 'data']));
        return ['success' => 'true', 'id' => $newSchema->id];
    }
}