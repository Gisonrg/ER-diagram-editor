<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Diagram extends Model
{
    protected $table = 'diagrams';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['data', 'name'];

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function getMeta() {
        return [
          'id' => $this->id,
            'name' => $this->name
        ];
    }
}
